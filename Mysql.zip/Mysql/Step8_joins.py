import mysql.connector
mydb = mysql.connector.connect(host="localhost", user="root", password="root", database ="employees")
mycursor = mydb.cursor()

join =("SELECT d.dept_no, d.dept_name, round(avg(s.salary),2) as salaries\
 from departments d join \
 dept_emp de on de.dept_no = d.dept_no join \
 salaries s on de.emp_no = s.emp_no group by d.dept_name ")

mycursor.execute(join)
myresult = mycursor.fetchall()
for x in myresult:
    print(x)


























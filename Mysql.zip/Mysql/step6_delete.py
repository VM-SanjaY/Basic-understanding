import mysql.connector
mydb = mysql.connector.connect(host="localhost",user="root",password="root",database="Login")
mycursor = mydb.cursor()

sq= "DELETE FROM details WHERE firstname = 'Vishnu'"
mycursor.execute(sq)
mydb.commit()

mycursor.execute("select * from details")
myresult = mycursor.fetchall()
for rowall in myresult:
    print(rowall)








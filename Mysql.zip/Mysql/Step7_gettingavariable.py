import mysql.connector
mydb = mysql.connector.connect(host="localhost", user="root", password="root", database="Login")
mycursor = mydb.cursor()


z = ("select username from details where username = %s")
x = input("Enter: ")
mycursor.execute(z, (x, ))

myresult = mycursor.fetchone()
for rowall in myresult:
    print(rowall)



import mysql.connector

# Creating a connection
mydb = mysql.connector.connect(
  host="localhost",
  user="root",
  password="root"
)
print(mydb)

# for checking if connection exist or not
if(mydb):
  print("Connection Successful")
else:
  print("Connection Failed")





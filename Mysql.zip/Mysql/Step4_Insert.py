import mysql.connector
mydb = mysql.connector.connect(host="localhost", user="root", password="root", database= "Login")
mycursor = mydb.cursor()
sqlinsert = "insert into details(Firstname,lastname,username,emailid) values(%s,%s,%s,%s)"

# %s is a placeholder that can be replaced. mostly use with placeholder itself

log = [("Sanjay","V M","Sanjay","sanjay@gamil.com"),("Karthik","V M","Karthik","karthik@gmail.com")]
mycursor.executemany(sqlinsert,log)  # since we are using a tuple
mydb.commit()



# to view the content from the table use

mycursor.execute("select * from details")   # insert of * you can use column name to what you want

myresult = mycursor.fetchone()   # fetches only one value

for row in myresult:           # you need to use for loop even if you want only one data
    print(row)

myresult = mycursor.fetchmany(10)  # fetches as per the parameter set in side the parenthesis
for rowm in myresult:           # you need to use for loop data
    print(rowm)


myresult = mycursor.fetchall()   # fetches only all value
for rowall in myresult:
    print(rowall)

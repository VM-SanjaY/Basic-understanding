import mysql.connector
mydb = mysql.connector.connect(host="localhost",user="root",password="root",database="Login")
mycusor=mydb.cursor()

sq="UPDATE details SET username = 'Vpriya' WHERE firstname = 'Vishnu'"  # string should be in quotes in the quotes
mycusor.execute(sq)
mydb.commit()














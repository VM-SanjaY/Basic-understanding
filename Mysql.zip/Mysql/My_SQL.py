import mysql.connector

mydb = mysql.connector.connect( host="localhost",user="root",password="root", database="ticket_reservation_system")
mycursor = mydb.cursor()



def login():
    print("""
    Welcome to the booking portal
    
    please login to continue
    
    """)
    global email
    email = input("Email ID: ")
    passwo = input("Password: ")
    val = (passwo, email)
    print(val)
    check = "SELECT username FROM User_table WHERE password = %s AND email = %s"
    mycursor.execute(check, val)
    myresult = mycursor.fetchone()
    if myresult:
        print("Login successful")
    else:
        print("Login failed")
login()       
        
        
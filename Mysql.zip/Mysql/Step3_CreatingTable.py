import mysql.connector
mydb = mysql.connector.connect(host="localhost", user="root", password="root", database="Login")
mycursor = mydb.cursor()
mycursor.execute("CREATE TABLE details (sno int primary key not null auto_increment, firstname varchar(60), lastname varchar(50), username Varchar(60),"
                 "email varchar(100), password varchar(100))")
# Things to note are parenthesis is marked properly or not and inserting the type along with the name
# first 3 lines are important for all codes
# to show table use

mycursor.execute("Show Tables")
for tb in mycursor:
    print(tb)





import os

os.remove("file path")     # this will remove the file

os.removedirs("file directory") # this will remove the directory

os.removexattr("file path")  # check on this function is available









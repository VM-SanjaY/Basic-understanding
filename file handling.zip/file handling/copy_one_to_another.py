# if the file is not inside your folder use the file path.

# when mention a file name if file do not exist it will create a file when we use "W"
read = open("hello.txt","r")
write = open("hi.txt","w")

# this will write the data from one file to another

for data in read:
    write.write(data)

# # # # # # # to write a image from file # # # # # #

image = open("school_logo.jpg", "rb")  # rb mean write binary images are binary(numbers) they are stored in numbers.
image2 = open("pic.jpg","wb")   # # wb mean write binary images are binary(numbers)
print(image.read()) #

# this will write the image from one file to another
for data in read:
    image.write(image2)







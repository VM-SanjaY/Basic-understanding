# with open() -  helps to open alot of files compare to just open()
# while True:
#     x = input("mention the file name you want to import: ")
#     fi = x+".txt"
#     fil = open(fi,"r")
#     print(fil.read())
#     do = input("Do you want to open another file(y/n): ").lower()
#     if do !="y":
#         break


# mer = input("do you want to merge files (y/n): ").lower()
# if mer == "y":
#     how = int(input("How many files do you want to merge(max 10): "))
#     i = 1
#     while i < how+1:
#         fi = input("Name of the file: ")
#         extension = fi+".txt"
#         read = open(extension, "r")
#         write = open("com.txt","a")
#         for f in read:
#             write.write(f)
#         i +=1
#
#     want = input("do you want to view the file: ").lower()
#     if want == "y":
#         x = "com"
#         fi = x + ".txt"
#         fil = open(fi, "r")
#         print(fil.read())
#     else:
#         print("thank you")


files = []
merged = ""
while True:
    filename = input("File name: ")
    files.append(filename)
    res = input("want to merger another file(y/n): ").lower()
    if res !="y":
        break
for file in files:
    filenames=file+".txt"
    f=open(filenames,mode="r",encoding='utf-8')
    merged = merged+f.read()+"\n"
    f.close()
print(merged)

name = input("Name of the result file: ")
name = name+".txt"
with open(name, mode="x", encoding="utf-8") as new:
    new.write(merged)
    print("File created")















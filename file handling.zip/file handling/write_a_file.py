# if the file is not inside your folder use the file path.

# when mention a file name if file do not exist it will create a file when we use "W"
write = open("hi.txt","w")

# this command writes stuff to the file.
write.write("Hi there minions")

# this says whether the file is writable or not
print(write.writable())

# this also write data to the file
write.writelines("Hi there minions, I am guru "
                 "listen to me")

# and if you want to add a new data to an existing file use append

write = open("hi.txt","a")   # use "a" instead of "w" and "a+" is used to append and read

# this way it will add this to that
write.write(" \nI am guru")

# # # # # # # to write a image from file # # # # # #

image = open("school_logo.jpg", "wb")  # wb mean write binary images are binary(numbers) they are stored in numbers.

print(image.read()) # result will be binaries and not the image.






# if the file is not inside your folder use the file path.
read = open('Hello.txt','r')

# will print the entire file

print(read.read())

# will print the first line and if you use the same code below will print second line

print(read.readline())

# and if you mention anything inside

print(read.readline(4))    # will print only four characters from the line

# will print all the data in sigle line

print(read.readlines())

# this state whether the file is readable or not

print(read.readable())


# # # # # # # to read a image from file # # # # # #

image = open("school_logo.jpg", "rb")  # rb mean read binary images are binary(numbers) they are stored in numbers.

print(image.read()) # result will be binaries and not the image.

# Important ************************************
# If you faced this error
# SyntaxError: (unicode error) 'unicodeescape' codec can't decode bytes in position 2-3: truncated \UXXXXXXXX escape
# then use "r" in front of the path it will run.

read = open(r'Hello.txt','r')  # I meant the r in the front of the path

print(read.read())






